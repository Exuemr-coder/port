import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { DeviceHeader } from "@/components/DeviceHeader";
import { type LightingMode, useMouse } from "@/context/MouseContext";
import { useColors } from "@/hooks/useColors";

const MODES: { id: LightingMode; label: string; desc: string; icon: string }[] = [
  { id: "off", label: "Kapalı", desc: "Işık yok", icon: "moon" },
  { id: "solid", label: "Sabit", desc: "Tek renk, sabit", icon: "sun" },
  { id: "breathing", label: "Nefes", desc: "Yavaş sönüp yanma", icon: "wind" },
  { id: "alternating", label: "Dönüşümlü", desc: "Renkler arası geçiş", icon: "repeat" },
  { id: "jump", label: "Atlama", desc: "Ani renk değişimi", icon: "zap" },
  { id: "flash", label: "Yanıp Sönme", desc: "Hızlı flaş", icon: "activity" },
];

const COLORS = [
  "#00e87a", "#00aaff", "#ff4444", "#ff6600",
  "#aa44ff", "#ffcc00", "#ffffff", "#00ffee",
  "#ff44aa", "#88ff00", "#0044ff", "#ff0088",
];

const BRIGHTNESS_STEPS = [20, 40, 60, 80, 100];

export default function LightingScreen() {
  const colors = useColors();
  const { lightingMode, lightingColor, lightingBrightness, setLightingMode, setLightingColor, setLightingBrightness } = useMouse();

  const activeMode = MODES.find((m) => m.id === lightingMode) ?? MODES[0];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <DeviceHeader />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Preview */}
        <View style={[styles.preview, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.previewMouse, { borderColor: lightingMode === "off" ? colors.border : lightingColor + "88" }]}>
            <View style={[styles.previewGlow, {
              backgroundColor: lightingMode === "off" ? "transparent" : lightingColor + "22",
              shadowColor: lightingMode === "off" ? "transparent" : lightingColor,
            }]} />
            <Ionicons name="hardware-chip-outline" size={32} color={lightingMode === "off" ? colors.mutedForeground : lightingColor} />
          </View>
          <View style={styles.previewInfo}>
            <Text style={[styles.previewMode, { color: colors.foreground }]}>{activeMode.label}</Text>
            <Text style={[styles.previewDesc, { color: colors.mutedForeground }]}>{activeMode.desc}</Text>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>IŞIK MODU</Text>
        <View style={styles.modeGrid}>
          {MODES.map((mode) => (
            <TouchableOpacity
              key={mode.id}
              style={[
                styles.modeCard,
                { backgroundColor: colors.card, borderColor: lightingMode === mode.id ? colors.primary : colors.border },
              ]}
              onPress={() => { Haptics.selectionAsync(); setLightingMode(mode.id); }}
              activeOpacity={0.7}
            >
              <Feather
                name={mode.icon as any}
                size={20}
                color={lightingMode === mode.id ? colors.primary : colors.mutedForeground}
              />
              <Text style={[styles.modeLabel, { color: lightingMode === mode.id ? colors.primary : colors.foreground }]}>
                {mode.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {lightingMode !== "off" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>RENK</Text>
            <View style={[styles.colorSection, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.colorGrid}>
                {COLORS.map((c) => (
                  <TouchableOpacity
                    key={c}
                    style={[
                      styles.colorDot,
                      { backgroundColor: c },
                      lightingColor === c && { borderWidth: 3, borderColor: "#fff" },
                    ]}
                    onPress={() => { Haptics.selectionAsync(); setLightingColor(c); }}
                  />
                ))}
              </View>
              <View style={[styles.selectedColorRow, { borderTopColor: colors.border }]}>
                <View style={[styles.selectedSwatch, { backgroundColor: lightingColor }]} />
                <Text style={[styles.selectedColorText, { color: colors.foreground }]}>
                  Seçili: {lightingColor.toUpperCase()}
                </Text>
              </View>
            </View>

            <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>PARİLTI</Text>
            <View style={[styles.brightnessSection, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.brightnessRow}>
                {BRIGHTNESS_STEPS.map((step) => (
                  <TouchableOpacity
                    key={step}
                    style={[
                      styles.brightnessBtn,
                      {
                        backgroundColor: lightingBrightness === step ? colors.primary : colors.secondary,
                        borderColor: lightingBrightness === step ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => { Haptics.selectionAsync(); setLightingBrightness(step); }}
                  >
                    <Text style={[styles.brightnessBtnText, { color: lightingBrightness === step ? colors.primaryForeground : colors.mutedForeground }]}>
                      {step}%
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              <View style={styles.brightnessBarBg}>
                <View style={[styles.brightnessBarFill, { backgroundColor: lightingColor, width: `${lightingBrightness}%` }]} />
              </View>
            </View>
          </>
        )}

        <View style={{ height: Platform.OS === "web" ? 34 : 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { padding: 16, gap: 14 },
  preview: { borderRadius: 16, borderWidth: 1, padding: 20, flexDirection: "row", alignItems: "center", gap: 16 },
  previewMouse: { width: 72, height: 72, borderRadius: 36, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  previewGlow: { position: "absolute", width: 72, height: 72, borderRadius: 36, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 16, elevation: 8 },
  previewInfo: { flex: 1 },
  previewMode: { fontSize: 18, fontFamily: "Inter_600SemiBold" },
  previewDesc: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 2 },
  sectionTitle: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 1.2 },
  modeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  modeCard: { width: "30%", flexGrow: 1, borderRadius: 12, borderWidth: 1.5, padding: 14, alignItems: "center", gap: 8 },
  modeLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  colorSection: { borderRadius: 14, borderWidth: 1, padding: 16, gap: 0 },
  colorGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12, justifyContent: "center" },
  colorDot: { width: 36, height: 36, borderRadius: 18 },
  selectedColorRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 14, paddingTop: 14, borderTopWidth: 1 },
  selectedSwatch: { width: 24, height: 24, borderRadius: 12 },
  selectedColorText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  brightnessSection: { borderRadius: 14, borderWidth: 1, padding: 16, gap: 14 },
  brightnessRow: { flexDirection: "row", gap: 8 },
  brightnessBtn: { flex: 1, borderRadius: 8, borderWidth: 1, paddingVertical: 10, alignItems: "center" },
  brightnessBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  brightnessBarBg: { height: 6, borderRadius: 3, backgroundColor: "#2a2a2a", overflow: "hidden" },
  brightnessBarFill: { height: 6, borderRadius: 3 },
});
