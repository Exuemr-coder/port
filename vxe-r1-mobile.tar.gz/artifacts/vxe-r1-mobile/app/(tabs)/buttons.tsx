import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { DeviceHeader } from "@/components/DeviceHeader";
import { type ButtonMapping, useMouse } from "@/context/MouseContext";
import { useColors } from "@/hooks/useColors";

const AVAILABLE_FUNCTIONS = [
  "Left Click", "Right Click", "Middle Click",
  "Browser Forward", "Browser Back", "DPI Switch",
  "Scroll Up", "Scroll Down", "Double Click",
  "Sniper Mode", "Fire Button",
  "Copy (Ctrl+C)", "Paste (Ctrl+V)", "Cut (Ctrl+X)",
  "Undo (Ctrl+Z)", "Redo (Ctrl+Y)", "Select All (Ctrl+A)",
  "Find (Ctrl+F)", "Close Tab (Ctrl+W)", "New Tab (Ctrl+T)",
  "Media Play/Pause", "Volume Up", "Volume Down", "Mute",
  "Windows Key", "Alt+F4", "Task Manager",
  "Macro 1", "Macro 2", "Macro 3",
  "Devre Dışı",
];

const BUTTON_ICONS: Record<string, string> = {
  left: "arrow-up-left",
  right: "arrow-up-right",
  middle: "circle",
  forward: "skip-forward",
  back: "skip-back",
  dpi: "target",
};

export default function ButtonsScreen() {
  const colors = useColors();
  const { buttonMappings, setButtonMappings } = useMouse();
  const [selectedBtn, setSelectedBtn] = useState<ButtonMapping | null>(null);

  function openPicker(btn: ButtonMapping) {
    Haptics.selectionAsync();
    setSelectedBtn(btn);
  }

  function applyMapping(fn: string) {
    if (!selectedBtn) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setButtonMappings(
      buttonMappings.map((b) => b.id === selectedBtn.id ? { ...b, mapping: fn } : b)
    );
    setSelectedBtn(null);
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <DeviceHeader />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Mouse diagram */}
        <View style={[styles.mouseWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.mouseBody, { borderColor: colors.border }]}>
            <View style={styles.mouseTop}>
              <View style={[styles.mouseBtn, { borderColor: colors.primary + "66", backgroundColor: colors.primary + "11" }]}>
                <Text style={[styles.mouseBtnLabel, { color: colors.primary }]}>Sol</Text>
              </View>
              <View style={[styles.mouseScroll, { backgroundColor: colors.border }]} />
              <View style={[styles.mouseBtn, { borderColor: colors.border, backgroundColor: colors.secondary }]}>
                <Text style={[styles.mouseBtnLabel, { color: colors.mutedForeground }]}>Sağ</Text>
              </View>
            </View>
            <View style={styles.mouseMiddle}>
              <View style={styles.mouseSideLeft}>
                <View style={[styles.sideBtn, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
                  <Text style={[styles.sideBtnText, { color: colors.mutedForeground }]}>◀ G</Text>
                </View>
                <View style={[styles.sideBtn, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
                  <Text style={[styles.sideBtnText, { color: colors.mutedForeground }]}>◀ İ</Text>
                </View>
              </View>
            </View>
            <View style={[styles.mouseDpi, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
              <Text style={[styles.mouseDpiText, { color: colors.mutedForeground }]}>DPI</Text>
            </View>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>BUTON ATAMASI</Text>

        {buttonMappings.map((btn) => (
          <TouchableOpacity
            key={btn.id}
            style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => openPicker(btn)}
            activeOpacity={0.7}
          >
            <View style={[styles.iconWrap, { backgroundColor: colors.secondary }]}>
              <Feather name={(BUTTON_ICONS[btn.id] || "circle") as any} size={16} color={colors.primary} />
            </View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowLabel, { color: colors.foreground }]}>{btn.label}</Text>
              <Text style={[styles.rowValue, { color: colors.mutedForeground }]}>{btn.mapping}</Text>
            </View>
            <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
          </TouchableOpacity>
        ))}

        <View style={{ height: Platform.OS === "web" ? 34 : 100 }} />
      </ScrollView>

      <Modal visible={!!selectedBtn} transparent animationType="slide">
        <Pressable style={styles.overlay} onPress={() => setSelectedBtn(null)}>
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>
              {selectedBtn?.label} — Fonksiyon Seç
            </Text>
            <FlatList
              data={AVAILABLE_FUNCTIONS}
              keyExtractor={(i) => i}
              scrollEnabled
              style={{ maxHeight: 360 }}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.fnRow,
                    { borderBottomColor: colors.border },
                    selectedBtn?.mapping === item && { backgroundColor: colors.primary + "15" },
                  ]}
                  onPress={() => applyMapping(item)}
                >
                  <Text style={[styles.fnText, { color: selectedBtn?.mapping === item ? colors.primary : colors.foreground }]}>
                    {item}
                  </Text>
                  {selectedBtn?.mapping === item && (
                    <Feather name="check" size={16} color={colors.primary} />
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { padding: 16, gap: 12 },
  mouseWrap: { borderRadius: 16, borderWidth: 1, padding: 20, alignItems: "center" },
  mouseBody: { width: 140, borderWidth: 1, borderRadius: 70, borderBottomLeftRadius: 50, borderBottomRightRadius: 50, overflow: "hidden", height: 200 },
  mouseTop: { flexDirection: "row", height: 80 },
  mouseBtn: { flex: 1, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  mouseBtnLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  mouseScroll: { width: 12, height: 80 },
  mouseMiddle: { flexDirection: "row", height: 80, position: "relative" },
  mouseSideLeft: { position: "absolute", left: -32, top: 8, gap: 6 },
  sideBtn: { width: 28, height: 22, borderRadius: 4, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  sideBtnText: { fontSize: 8, fontFamily: "Inter_500Medium" },
  mouseDpi: { height: 40, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  mouseDpiText: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 1 },
  sectionTitle: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 1.2, marginTop: 4 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1, padding: 14 },
  iconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  rowContent: { flex: 1 },
  rowLabel: { fontSize: 15, fontFamily: "Inter_500Medium" },
  rowValue: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 1 },
  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "#00000077" },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, borderWidth: 1, padding: 20, gap: 14 },
  handle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center" },
  sheetTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  fnRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 13, borderBottomWidth: 1 },
  fnText: { fontSize: 15, fontFamily: "Inter_400Regular" },
});
