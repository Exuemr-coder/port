import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type DpiStage = {
  id: string;
  value: number;
  color: string;
  active: boolean;
};

export type PollingRate = "125" | "250" | "500" | "1000" | "4000";
export type LightingMode = "off" | "solid" | "breathing" | "alternating" | "jump" | "flash";
export type LOD = "low" | "medium" | "high";

export type ButtonMapping = {
  id: string;
  label: string;
  mapping: string;
};

type MouseContextType = {
  connected: boolean;
  batteryLevel: number;
  dpiStages: DpiStage[];
  pollingRate: PollingRate;
  buttonMappings: ButtonMapping[];
  lightingMode: LightingMode;
  lightingColor: string;
  lightingBrightness: number;
  debounceTime: number;
  lod: LOD;
  motionSync: boolean;
  angleSnapping: boolean;
  firmwareVersion: string;
  setDpiStages: (stages: DpiStage[]) => void;
  setPollingRate: (rate: PollingRate) => void;
  setButtonMappings: (mappings: ButtonMapping[]) => void;
  setLightingMode: (mode: LightingMode) => void;
  setLightingColor: (color: string) => void;
  setLightingBrightness: (v: number) => void;
  setDebounceTime: (v: number) => void;
  setLod: (v: LOD) => void;
  setMotionSync: (v: boolean) => void;
  setAngleSnapping: (v: boolean) => void;
};

const DEFAULT_DPI_STAGES: DpiStage[] = [
  { id: "1", value: 400, color: "#ffffff", active: false },
  { id: "2", value: 800, color: "#00e87a", active: true },
  { id: "3", value: 1600, color: "#00aaff", active: false },
  { id: "4", value: 3200, color: "#ff6600", active: false },
];

const DEFAULT_BUTTON_MAPPINGS: ButtonMapping[] = [
  { id: "left", label: "Sol Tık", mapping: "Left Click" },
  { id: "right", label: "Sağ Tık", mapping: "Right Click" },
  { id: "middle", label: "Orta Tık", mapping: "Middle Click" },
  { id: "forward", label: "İleri", mapping: "Browser Forward" },
  { id: "back", label: "Geri", mapping: "Browser Back" },
  { id: "dpi", label: "DPI Butonu", mapping: "DPI Switch" },
];

const MouseContext = createContext<MouseContextType | null>(null);

const STORAGE_KEY = "@vxer1_settings";

export function MouseProvider({ children }: { children: React.ReactNode }) {
  const [connected] = useState(true);
  const [batteryLevel] = useState(78);
  const [dpiStages, setDpiStagesState] = useState<DpiStage[]>(DEFAULT_DPI_STAGES);
  const [pollingRate, setPollingRateState] = useState<PollingRate>("1000");
  const [buttonMappings, setButtonMappingsState] = useState<ButtonMapping[]>(DEFAULT_BUTTON_MAPPINGS);
  const [lightingMode, setLightingModeState] = useState<LightingMode>("breathing");
  const [lightingColor, setLightingColorState] = useState("#00e87a");
  const [lightingBrightness, setLightingBrightnessState] = useState(80);
  const [debounceTime, setDebounceTimeState] = useState(4);
  const [lod, setLodState] = useState<LOD>("medium");
  const [motionSync, setMotionSyncState] = useState(true);
  const [angleSnapping, setAngleSnappingState] = useState(false);
  const firmwareVersion = "v2.3.1";

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((data) => {
      if (!data) return;
      try {
        const parsed = JSON.parse(data);
        if (parsed.dpiStages) setDpiStagesState(parsed.dpiStages);
        if (parsed.pollingRate) setPollingRateState(parsed.pollingRate);
        if (parsed.buttonMappings) setButtonMappingsState(parsed.buttonMappings);
        if (parsed.lightingMode) setLightingModeState(parsed.lightingMode);
        if (parsed.lightingColor) setLightingColorState(parsed.lightingColor);
        if (parsed.lightingBrightness != null) setLightingBrightnessState(parsed.lightingBrightness);
        if (parsed.debounceTime != null) setDebounceTimeState(parsed.debounceTime);
        if (parsed.lod) setLodState(parsed.lod);
        if (parsed.motionSync != null) setMotionSyncState(parsed.motionSync);
        if (parsed.angleSnapping != null) setAngleSnappingState(parsed.angleSnapping);
      } catch {}
    });
  }, []);

  const save = useCallback((update: Partial<Record<string, unknown>>) => {
    AsyncStorage.getItem(STORAGE_KEY).then((data) => {
      const current = data ? JSON.parse(data) : {};
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ ...current, ...update }));
    });
  }, []);

  const setDpiStages = (v: DpiStage[]) => { setDpiStagesState(v); save({ dpiStages: v }); };
  const setPollingRate = (v: PollingRate) => { setPollingRateState(v); save({ pollingRate: v }); };
  const setButtonMappings = (v: ButtonMapping[]) => { setButtonMappingsState(v); save({ buttonMappings: v }); };
  const setLightingMode = (v: LightingMode) => { setLightingModeState(v); save({ lightingMode: v }); };
  const setLightingColor = (v: string) => { setLightingColorState(v); save({ lightingColor: v }); };
  const setLightingBrightness = (v: number) => { setLightingBrightnessState(v); save({ lightingBrightness: v }); };
  const setDebounceTime = (v: number) => { setDebounceTimeState(v); save({ debounceTime: v }); };
  const setLod = (v: LOD) => { setLodState(v); save({ lod: v }); };
  const setMotionSync = (v: boolean) => { setMotionSyncState(v); save({ motionSync: v }); };
  const setAngleSnapping = (v: boolean) => { setAngleSnappingState(v); save({ angleSnapping: v }); };

  return (
    <MouseContext.Provider value={{
      connected, batteryLevel, dpiStages, pollingRate, buttonMappings,
      lightingMode, lightingColor, lightingBrightness, debounceTime, lod,
      motionSync, angleSnapping, firmwareVersion,
      setDpiStages, setPollingRate, setButtonMappings, setLightingMode,
      setLightingColor, setLightingBrightness, setDebounceTime, setLod,
      setMotionSync, setAngleSnapping,
    }}>
      {children}
    </MouseContext.Provider>
  );
}

export function useMouse() {
  const ctx = useContext(MouseContext);
  if (!ctx) throw new Error("useMouse must be used inside MouseProvider");
  return ctx;
}
