import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { DeviceHeader } from "@/components/DeviceHeader";
import { type LOD, type PollingRate, useMouse } from "@/context/MouseContext";
import { useColors } from "@/hooks/useColors";

const POLLING_RATES: PollingRate[] = ["125", "250", "500", "1000", "4000"];
const LOD_OPTIONS: { id: LOD; label: string; desc: string }[] = [
  { id: "low", label: "Düşük", desc: "~1mm" },
  { id: "medium", label: "Orta", desc: "~2mm" },
  { id: "high", label: "Yüksek", desc: "~3mm" },
];
const DEBOUNCE_STEPS = [2, 4, 6, 8, 10, 12, 14, 16];

export default function SettingsScreen() {
  const colors = useColors();
  const {
    pollingRate, setPollingRate,
    debounceTime, setDebounceTime,
    lod, setLod,
    motionSync, setMotionSync,
    angleSnapping, setAngleSnapping,
    firmwareVersion,
  } = useMouse();

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <DeviceHeader />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Polling Rate */}
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>POLLING RATE</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.pollingRow}>
            {POLLING_RATES.map((rate) => (
              <TouchableOpacity
                key={rate}
                style={[
                  styles.pollingBtn,
                  { borderColor: pollingRate === rate ? colors.primary : colors.border, backgroundColor: pollingRate === rate ? colors.primary + "18" : colors.secondary },
                ]}
                onPress={() => { Haptics.selectionAsync(); setPollingRate(rate); }}
              >
                <Text style={[styles.pollingBtnText, { color: pollingRate === rate ? colors.primary : colors.mutedForeground }]}>
                  {rate}
                </Text>
                <Text style={[styles.pollingBtnUnit, { color: pollingRate === rate ? colors.primary + "aa" : colors.mutedForeground + "88" }]}>
                  Hz
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={[styles.pollingHint, { color: colors.mutedForeground }]}>
            {pollingRate === "4000" ? "Ultra yüksek \u2014 4K alıcı gerektirir" :
             pollingRate === "1000" ? "Standart oyun performansı" :
             pollingRate === "500" ? "İyi performans, düşük CPU kullanımı" :
             "Düşük performans modu"}
          </Text>
        </View>

        {/* Debounce */}
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>DEBOUNCE SÜRESİ</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.debounceHeader}>
            <Text style={[styles.debounceValue, { color: colors.foreground }]}>{debounceTime}ms</Text>
            <Text style={[styles.debounceDesc, { color: colors.mutedForeground }]}>Tık gecikmesi</Text>
          </View>
          <View style={styles.debounceSteps}>
            {DEBOUNCE_STEPS.map((step) => (
              <TouchableOpacity
                key={step}
                style={[
                  styles.debounceStep,
                  { backgroundColor: debounceTime === step ? colors.primary : colors.secondary, borderColor: debounceTime === step ? colors.primary : colors.border },
                ]}
                onPress={() => { Haptics.selectionAsync(); setDebounceTime(step); }}
              >
                <Text style={[styles.debounceStepText, { color: debounceTime === step ? colors.primaryForeground : colors.mutedForeground }]}>
                  {step}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.debounceBarBg}>
            <View style={[styles.debounceBarFill, { backgroundColor: colors.primary, width: `${((debounceTime - 2) / 14) * 100}%` }]} />
          </View>
          <View style={styles.debounceRange}>
            <Text style={[styles.debounceRangeText, { color: colors.mutedForeground }]}>2ms (hızlı)</Text>
            <Text style={[styles.debounceRangeText, { color: colors.mutedForeground }]}>16ms (stabil)</Text>
          </View>
        </View>

        {/* LOD */}
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>KALDIRMA MESAFESİ (LOD)</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {LOD_OPTIONS.map((opt, i) => (
            <TouchableOpacity
              key={opt.id}
              style={[
                styles.lodRow,
                i < LOD_OPTIONS.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border },
                lod === opt.id && { backgroundColor: colors.primary + "0a" },
              ]}
              onPress={() => { Haptics.selectionAsync(); setLod(opt.id); }}
            >
              <View style={styles.lodLeft}>
                <Ionicons
                  name={lod === opt.id ? "radio-button-on" : "radio-button-off"}
                  size={18}
                  color={lod === opt.id ? colors.primary : colors.mutedForeground}
                />
                <Text style={[styles.lodLabel, { color: lod === opt.id ? colors.primary : colors.foreground }]}>
                  {opt.label}
                </Text>
              </View>
              <Text style={[styles.lodDesc, { color: colors.mutedForeground }]}>{opt.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Toggles */}
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>SENSÖR AYARLARI</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.toggleRow, { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
            <View style={styles.toggleLeft}>
              <Feather name="refresh-cw" size={18} color={colors.primary} />
              <View>
                <Text style={[styles.toggleLabel, { color: colors.foreground }]}>Motion Sync</Text>
                <Text style={[styles.toggleDesc, { color: colors.mutedForeground }]}>Sensör senkronizasyonu</Text>
              </View>
            </View>
            <Switch
              value={motionSync}
              onValueChange={(v) => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setMotionSync(v); }}
              trackColor={{ false: colors.secondary, true: colors.primary + "88" }}
              thumbColor={motionSync ? colors.primary : colors.mutedForeground}
            />
          </View>
          <View style={styles.toggleRow}>
            <View style={styles.toggleLeft}>
              <Feather name="maximize-2" size={18} color={colors.primary} />
              <View>
                <Text style={[styles.toggleLabel, { color: colors.foreground }]}>Angle Snapping</Text>
                <Text style={[styles.toggleDesc, { color: colors.mutedForeground }]}>Düz çizgi düzeltme</Text>
              </View>
            </View>
            <Switch
              value={angleSnapping}
              onValueChange={(v) => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setAngleSnapping(v); }}
              trackColor={{ false: colors.secondary, true: colors.primary + "88" }}
              thumbColor={angleSnapping ? colors.primary : colors.mutedForeground}
            />
          </View>
        </View>

        {/* Firmware */}
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>CİHAZ</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.fwRow, { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
            <Text style={[styles.fwLabel, { color: colors.foreground }]}>Firmware</Text>
            <Text style={[styles.fwValue, { color: colors.mutedForeground }]}>{firmwareVersion}</Text>
          </View>
          <View style={styles.fwRow}>
            <Text style={[styles.fwLabel, { color: colors.foreground }]}>Model</Text>
            <Text style={[styles.fwValue, { color: colors.mutedForeground }]}>VXE R1</Text>
          </View>
        </View>

        <View style={{ height: Platform.OS === "web" ? 34 : 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { padding: 16, gap: 12 },
  sectionTitle: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 1.2, marginTop: 4 },
  card: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  pollingRow: { flexDirection: "row", padding: 12, gap: 8 },
  pollingBtn: { flex: 1, borderRadius: 10, borderWidth: 1.5, paddingVertical: 12, alignItems: "center" },
  pollingBtnText: { fontSize: 14, fontFamily: "Inter_700Bold" },
  pollingBtnUnit: { fontSize: 10, fontFamily: "Inter_400Regular" },
  pollingHint: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center", paddingBottom: 12 },
  debounceHeader: { flexDirection: "row", alignItems: "baseline", gap: 8, padding: 16, paddingBottom: 12 },
  debounceValue: { fontSize: 32, fontFamily: "Inter_700Bold" },
  debounceDesc: { fontSize: 13, fontFamily: "Inter_400Regular" },
  debounceSteps: { flexDirection: "row", flexWrap: "wrap", gap: 8, paddingHorizontal: 16, paddingBottom: 12 },
  debounceStep: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 8, borderWidth: 1 },
  debounceStepText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  debounceBarBg: { height: 4, marginHorizontal: 16, borderRadius: 2, backgroundColor: "#2a2a2a", overflow: "hidden", marginBottom: 6 },
  debounceBarFill: { height: 4, borderRadius: 2, minWidth: 4 },
  debounceRange: { flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14 },
  debounceRangeText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  lodRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14, paddingHorizontal: 16 },
  lodLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  lodLabel: { fontSize: 15, fontFamily: "Inter_500Medium" },
  lodDesc: { fontSize: 13, fontFamily: "Inter_400Regular" },
  toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14, paddingHorizontal: 16 },
  toggleLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  toggleLabel: { fontSize: 15, fontFamily: "Inter_500Medium" },
  toggleDesc: { fontSize: 12, fontFamily: "Inter_400Regular" },
  fwRow: { flexDirection: "row", justifyContent: "space-between", padding: 14, paddingHorizontal: 16 },
  fwLabel: { fontSize: 15, fontFamily: "Inter_500Medium" },
  fwValue: { fontSize: 14, fontFamily: "Inter_400Regular" },
});
