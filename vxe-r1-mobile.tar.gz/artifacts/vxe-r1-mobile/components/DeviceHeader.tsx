import { Feather, Ionicons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useMouse } from "@/context/MouseContext";
import { useColors } from "@/hooks/useColors";

export function DeviceHeader() {
  const colors = useColors();
  const { connected, batteryLevel } = useMouse();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const batteryIcon =
    batteryLevel > 60 ? "battery-full" : batteryLevel > 30 ? "battery" : "battery-low";

  return (
    <View style={[styles.container, { backgroundColor: colors.card, borderBottomColor: colors.border, paddingTop: topPad + 12 }]}>
      <View style={styles.row}>
        <View style={styles.left}>
          <View style={[styles.dot, { backgroundColor: connected ? "#00e87a" : "#ff4444" }]} />
          <Text style={[styles.deviceName, { color: colors.foreground }]}>VXE R1</Text>
          <View style={[styles.badge, { backgroundColor: connected ? "#00e87a22" : "#ff444422", borderColor: connected ? "#00e87a44" : "#ff444444" }]}>
            <Text style={[styles.badgeText, { color: connected ? "#00e87a" : "#ff4444" }]}>
              {connected ? "Bağlı" : "Bağlı Değil"}
            </Text>
          </View>
        </View>
        <View style={styles.right}>
          <Ionicons name={batteryIcon as any} size={18} color={batteryLevel < 20 ? "#ff4444" : colors.mutedForeground} />
          <Text style={[styles.battery, { color: batteryLevel < 20 ? "#ff4444" : colors.mutedForeground }]}>
            {batteryLevel}%
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  deviceName: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 11,
    fontFamily: "Inter_500Medium",
  },
  right: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  battery: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
});
