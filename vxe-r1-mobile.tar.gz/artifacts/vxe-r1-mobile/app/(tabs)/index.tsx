import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { DeviceHeader } from "@/components/DeviceHeader";
import { type DpiStage, useMouse } from "@/context/MouseContext";
import { useColors } from "@/hooks/useColors";

const STAGE_COLORS = [
  "#ffffff", "#00e87a", "#00aaff", "#ff6600",
  "#ff4444", "#aa44ff", "#ffcc00", "#00ffee",
];

const MAX_DPI = 26000;
const MIN_DPI = 50;

export default function DpiScreen() {
  const colors = useColors();
  const { dpiStages, setDpiStages } = useMouse();
  const [colorPickerFor, setColorPickerFor] = useState<string | null>(null);

  function setActive(id: string) {
    Haptics.selectionAsync();
    setDpiStages(dpiStages.map((s) => ({ ...s, active: s.id === id })));
  }

  function updateValue(id: string, raw: string) {
    const num = parseInt(raw.replace(/[^0-9]/g, ""), 10);
    if (isNaN(num)) return;
    const clamped = Math.min(MAX_DPI, Math.max(MIN_DPI, num));
    setDpiStages(dpiStages.map((s) => s.id === id ? { ...s, value: clamped } : s));
  }

  function updateColor(id: string, color: string) {
    Haptics.selectionAsync();
    setDpiStages(dpiStages.map((s) => s.id === id ? { ...s, color } : s));
    setColorPickerFor(null);
  }

  function deleteStage(id: string) {
    if (dpiStages.length <= 1) return Alert.alert("En az 1 aşama gerekli");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    const updated = dpiStages.filter((s) => s.id !== id);
    if (!updated.some((s) => s.active)) updated[0].active = true;
    setDpiStages(updated);
  }

  function addStage() {
    if (dpiStages.length >= 5) return Alert.alert("Maksimum 5 aşama");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const newStage: DpiStage = {
      id: Date.now().toString(),
      value: 1600,
      color: "#888888",
      active: false,
    };
    setDpiStages([...dpiStages, newStage]);
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <DeviceHeader />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>DPI AŞAMALARI</Text>

        {dpiStages.map((stage, index) => (
          <View key={stage.id} style={[styles.stageCard, { backgroundColor: colors.card, borderColor: stage.active ? colors.primary : colors.border }]}>
            <View style={styles.stageTop}>
              <View style={styles.stageLeft}>
                <TouchableOpacity
                  onPress={() => setColorPickerFor(stage.id)}
                  style={[styles.colorDot, { backgroundColor: stage.color }]}
                />
                <Text style={[styles.stageLabel, { color: colors.mutedForeground }]}>
                  Aşama {index + 1}
                </Text>
              </View>
              <View style={styles.stageRight}>
                {stage.active && (
                  <View style={[styles.activeBadge, { backgroundColor: colors.primary + "22", borderColor: colors.primary + "44" }]}>
                    <Text style={[styles.activeBadgeText, { color: colors.primary }]}>AKTİF</Text>
                  </View>
                )}
                <TouchableOpacity onPress={() => deleteStage(stage.id)} style={styles.deleteBtn}>
                  <Feather name="trash-2" size={15} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.dpiRow}>
              <TextInput
                style={[styles.dpiInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.secondary }]}
                value={stage.value.toString()}
                onChangeText={(v) => updateValue(stage.id, v)}
                keyboardType="numeric"
                selectTextOnFocus
              />
              <Text style={[styles.dpiUnit, { color: colors.mutedForeground }]}>DPI</Text>
            </View>

            <View style={styles.dpiBarBg}>
              <View
                style={[
                  styles.dpiBarFill,
                  {
                    backgroundColor: stage.color,
                    width: `${((stage.value - MIN_DPI) / (MAX_DPI - MIN_DPI)) * 100}%`,
                  },
                ]}
              />
            </View>

            <View style={styles.dpiRange}>
              <Text style={[styles.dpiRangeText, { color: colors.mutedForeground }]}>50</Text>
              <Text style={[styles.dpiRangeText, { color: colors.mutedForeground }]}>26000</Text>
            </View>

            <TouchableOpacity
              style={[styles.activateBtn, { backgroundColor: stage.active ? colors.primary + "18" : colors.secondary, borderColor: stage.active ? colors.primary : colors.border }]}
              onPress={() => setActive(stage.id)}
            >
              <Ionicons
                name={stage.active ? "radio-button-on" : "radio-button-off"}
                size={16}
                color={stage.active ? colors.primary : colors.mutedForeground}
              />
              <Text style={[styles.activateBtnText, { color: stage.active ? colors.primary : colors.mutedForeground }]}>
                {stage.active ? "Aktif Aşama" : "Aktif Yap"}
              </Text>
            </TouchableOpacity>
          </View>
        ))}

        {dpiStages.length < 5 && (
          <TouchableOpacity
            style={[styles.addBtn, { borderColor: colors.border, backgroundColor: colors.card }]}
            onPress={addStage}
          >
            <Feather name="plus" size={18} color={colors.primary} />
            <Text style={[styles.addBtnText, { color: colors.primary }]}>Aşama Ekle</Text>
          </TouchableOpacity>
        )}

        <Text style={[styles.hint, { color: colors.mutedForeground }]}>
          Renk noktasına basarak aşama rengini değiştirebilirsin.
        </Text>

        <View style={{ height: Platform.OS === "web" ? 34 : 100 }} />
      </ScrollView>

      <Modal visible={!!colorPickerFor} transparent animationType="fade">
        <Pressable style={styles.modalOverlay} onPress={() => setColorPickerFor(null)}>
          <View style={[styles.colorPicker, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.colorPickerTitle, { color: colors.foreground }]}>Renk Seç</Text>
            <View style={styles.colorGrid}>
              {STAGE_COLORS.map((c) => (
                <TouchableOpacity
                  key={c}
                  style={[styles.colorOption, { backgroundColor: c }]}
                  onPress={() => colorPickerFor && updateColor(colorPickerFor, c)}
                />
              ))}
            </View>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { padding: 16, gap: 12 },
  sectionTitle: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 1.2, marginBottom: 4 },
  stageCard: { borderRadius: 14, borderWidth: 1.5, padding: 16, gap: 12 },
  stageTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  stageLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  colorDot: { width: 20, height: 20, borderRadius: 10 },
  stageLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  stageRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  activeBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, borderWidth: 1 },
  activeBadgeText: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 0.8 },
  deleteBtn: { padding: 4 },
  dpiRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  dpiInput: {
    fontSize: 28, fontFamily: "Inter_700Bold",
    borderWidth: 1, borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 8,
    minWidth: 120, textAlign: "center",
  },
  dpiUnit: { fontSize: 14, fontFamily: "Inter_500Medium" },
  dpiBarBg: { height: 6, borderRadius: 3, backgroundColor: "#2a2a2a", overflow: "hidden" },
  dpiBarFill: { height: 6, borderRadius: 3, minWidth: 4 },
  dpiRange: { flexDirection: "row", justifyContent: "space-between" },
  dpiRangeText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  activateBtn: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 10, borderWidth: 1, padding: 10, justifyContent: "center" },
  activateBtnText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  addBtn: { borderWidth: 1.5, borderStyle: "dashed", borderRadius: 14, padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  addBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  hint: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center", marginTop: 4 },
  modalOverlay: { flex: 1, backgroundColor: "#00000088", justifyContent: "center", alignItems: "center" },
  colorPicker: { borderRadius: 16, borderWidth: 1, padding: 20, width: 260, gap: 16 },
  colorPickerTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  colorGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12, justifyContent: "center" },
  colorOption: { width: 40, height: 40, borderRadius: 20 },
});
